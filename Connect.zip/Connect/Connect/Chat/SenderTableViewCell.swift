//
//  SenderTableViewCell.swift
//  Connect
//
//  Created by zetao on 15/3/2019.
//  Copyright © 2019 zetao. All rights reserved.
//

import UIKit

class SenderTableViewCell: UITableViewCell {
    
    //    //如何在cell 里面显示来自网络的图片，视频，文字？ 视频图片都显示微缩图，让cell跟着文字长度变，但是有一个最大长度限制
    

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    
    
    
    
    
    
}
