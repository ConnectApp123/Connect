//
//  ChatCellTableViewCell.swift
//  Connect
//
//  Created by zetao on 13/3/2019.
//  Copyright © 2019 zetao. All rights reserved.
//

import UIKit

class ChatCellTableViewCell: MGSwipeTableCell {

    @IBOutlet var UserImage: UIImageView!
    @IBOutlet var Name: UILabel!
    @IBOutlet var Message: UITextField!
    @IBOutlet var Time: UILabel!

    func loadUserImage() {
        
    }

    func loadUserName() {
        
    }
    
    func loadMessage() {
        
    }
    
    func loadTime() {
        
    }
    
    
}
