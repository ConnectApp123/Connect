
//  ChatViewController.swift
//  Connect
//
//  Created by zetao on 10/3/2019.
//  Copyright © 2019 zetao. All rights reserved.
//

import UIKit

class ChatsView: UIViewController, UISearchBarDelegate, UITableViewDataSource, UITableViewDelegate, MGSwipeTableCellDelegate, SelectUserDelegate {


    @IBOutlet var searchBar: UISearchBar!
    @IBOutlet var tableView: UITableView!
    
    private var timer: Timer
  //  private var dbchats: RLMResults = DBChat.objects(with: NSPredicate(value: fasle))
    
        
    
    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        
        tabBarItem.image = UIImage(named: "tab_chats@2x")
        tabBarItem.title = "Chats"
        
        //添加观察者 添加函数
//        NotificationCenterX.addObserver(target: self, selector: #selector(actionCleanup), name: NOTIFICATION_USER_LOGGED_OUT)
//        NotificationCenterX.addObserver(target: self, selector: #selector(refreshTableView), name: NOTIFICATION_USER_LOGGED_IN)
//        NotificationCenterX.addObserver(target: self, selector: #selector(refreshTabCounter), name: NOTIFICATION_USER_LOGGED_IN)
//        NotificationCenterX.addObserver(target: self, selector: #selector(refreshTableView), name: NOTIFICATION_REFRESH_CHATS)
//        NotificationCenterX.addObserver(target: self, selector: #selector(refreshTabCounter), name: NOTIFICATION_REFRESH_CHATS)
//        NotificationCenterX.addObserver(target: self, selector: #selector(refreshTableView), name: NOTIFICATION_REFRESH_STATUSES)
//        NotificationCenterX.addObserver(target: self, selector: #selector(refreshTabCounter), name: NOTIFICATION_REFRESH_STATUSES)
    }
    
    required init?(coder aDecoder: NSCoder) {
        
        super.init(coder: aDecoder)
    }
    

    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Chats"

        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .compose, target: .self, action: #selector(actionCompose))
        timer = Timer.scheduledTimer(timeInterval: 30.0, target: self, selector: #selector(refreshTableView), userInfo: nil, repeats: true)
        tableView.register(UINib(nibName: "ChatCell", bundle: nil), forCellReuseIdentifier: "ChatsCell")
        tableView.tableFooterView = UIView()

        loadChats()
     }


 
    
    
    //TODO: register and refresh
    // 没有注册的，打开app，首先展示注册界面。注册完以后，引导到资料设置界面，昵称必须填写，为空提示。如果已经登录，并且设置好资料，更新聊天界面
    
    //MARK: -Realm methods
    func loadChats() {
        
    }
    
    //如果点击tableview cell，进入聊天界面，那么每个聊天都应该有一个ID，对应一个聊天。点击加号，选择创建群聊，默认名字群聊。
    //MARK: -Refresh methods
    @objc func refreshTableView() {
        
    }
    
    func refreshTabCounter() {
        
    }
    
    //MARK: -User actions
    func actionCompose() {
        
    }
    
    //MARK: -Select more
    func actionMore() {
        
    }
    
    func actionArchive() {
        
    }
    
    func actionDelete() {
        
    }
    
    func actionMute() {
        
    }
    
    func actionClear() {
        
    }
    
    func actionExportCallHistory() {
        
    }
    
    func actionDissmiss() {
        
    }
    
    
    
 }
