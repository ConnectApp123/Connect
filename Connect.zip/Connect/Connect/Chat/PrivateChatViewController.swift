//
//  PrivateChatViewController.swift
//  Connect
//
//  Created by zetao on 22/2/2019.
//  Copyright © 2019 zetao. All rights reserved.
//

import UIKit


class PrivateChatViewController:UIViewController, RCMessagesView, UIGestureRecognizerDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, AudioDelegate, StickerDelegate, SelectUserDelegate,UITextFieldDelegate, UITableViewDelegate,UITableViewDataSource{
    
    @IBOutlet weak var input: UITextField!
    @IBOutlet weak var emoji: UIButton!
    
    
    
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let buttonBack = UIBarButtonItem(image: "chat_back", style: .plain, target: self, action: #selector(actionBack))
        let buttonPlus = UIBarButtonItem(image: "chat_plus", style: .plain, target: self, action: #selector(actionChatSetting))
        
        UINavigationItem.leftBarButtonItem = buttonBack
        UINavigationItem.rightBarButtonItems = buttonPlus
        
        //set button of doubule side of the textfield
        let buttonSend = UIButton(type: .custom)
        buttonSend.setImage(UIImage(named: "microphone.png"), for: .normal)
        buttonSend.imageEdgeInsets = UIEdgeInsets(top: 0, left: -16, bottom: 0, right: 0)
        input.rightView = buttonSend
        input.rightViewMode = .always
        
        let buttonMore = UIButton(type: .custom)
        buttonMore.setImage(UIImage(named: "more.png"), for: .normal)
        buttonMore.imageEdgeInsets = UIEdgeInsets(top: 0, left: -16, bottom: 0, right: 0)
        input.leftView = buttonMore
        input.rightViewMode = .always
    }
    
    //textfield 输入文字，输入时麦克风标志，改为发送标志，同时输出到senderCell 的textfiled 里面，并且判断是否发送成功
    //点击emoji弹出表情，点击plus弹出 alerview 进行 多项功能选择 包括：拍照，选择相片，录制视频，发送名片，共享位置，发送红包
    
    //可以使用枚举来为多个textfiled 设立delegate
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        let buttonSend = UIButton(type: .custom)
        buttonSend.setImage(UIImage(named: "send.png"), for: .normal)
        input.leftView = buttonSend
        input.rightViewMode = .always
    }
   
    
    
    
    func plusButton() {
        
        let alert = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)
        
        var alertCamera = UIAlertAction(title: "Camera", style: .default, handler: { action in
            PresentMultiCamera(target: self, edit: true)
        })
        var alertPicture = UIAlertAction(title: "Picture", style: .default, handler: { action in
            PresentPhotoLibrary(target: self, edit: true)
        })
        var alertVideo = UIAlertAction(title: "Video", style: .default, handler: { action in
            PresentVideoLibrary(target: self, edit: true)
        })
        var alertAudio = UIAlertAction(title: "Audio", style: .default, handler: { action in
            self.actionAudio()
        })
        var alertStickers = UIAlertAction(title: "Sticker", style: .default, handler: { action in
            self.actionStickers()
        })
        var alertLocation = UIAlertAction(title: "Location", style: .default, handler: { action in
            self.actionLocation()
        })
        
        alertCamera.setValue(UIImage(named: "chat_camera"), forKey: "image")
        alert.addAction(alertCamera)
        alertPicture.setValue(UIImage(named: "chat_picture"), forKey: "image")
        alert.addAction(alertPicture)
        alertVideo.setValue(UIImage(named: "chat_video"), forKey: "image")
        alert.addAction(alertVideo)
        alertAudio.setValue(UIImage(named: "chat_audio"), forKey: "image")
        alert.addAction(alertAudio)
        alertStickers.setValue(UIImage(named: "chat_sticker"), forKey: "image")
        alert.addAction(alertStickers)
        alertLocation.setValue(UIImage(named: "chat_location"), forKey: "image")
        alert.addAction(alertLocation)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true)
    }
    
    //message 为单数使用senderCell 如果为双数，使用recipientCell
    func messageCell() {
        
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
}
