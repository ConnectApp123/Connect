//
//  LoginPhoneView.swift
//  Connect
//
//  Created by zetao on 2019/6/9.
//  Copyright © 2019 zetao. All rights reserved.
//

@objc protocol LoginPhoneDelegate: class {
    
    func didLoginPhone()
}

