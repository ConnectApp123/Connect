//
//  SignupViewController.swift
//  Connect
//
//  Created by zetao on 22/2/2019.
//  Copyright © 2019 zetao. All rights reserved.
//

import UIKit

class SignupViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    
    //选择区号，输入手机号码，输入两边密码，获取验证码，然后下一步显示隐私说明，使用说明，然后进入个人资料界面
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
