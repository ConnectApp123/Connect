//
//  FriendsViewController.swift
//  Connect
//
//  Created by zetao on 22/2/2019.
//  Copyright © 2019 zetao. All rights reserved.
//

import UIKit

class FriendsViewController: UIViewController {
    //加载
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override init(nibName nibNameOrNil: String?, bundle nibBundleOrNil: Bundle?) {
        
        super.init(nibName: nibNameOrNil, bundle: nibBundleOrNil)
        
        tabBarItem.image = UIImage(named: "tab_people@2x")
        tabBarItem.title = "Friends"

        
        
        //        //添加观察者 添加函数
        //        NotificationCenterX.addObserver(target: self, selector: #selector(actionCleanup), name: NOTIFICATION_USER_LOGGED_OUT)
        //        NotificationCenterX.addObserver(target: self, selector: #selector(refreshTableView), name: NOTIFICATION_USER_LOGGED_IN)
        //        NotificationCenterX.addObserver(target: self, selector: #selector(refreshTabCounter), name: NOTIFICATION_USER_LOGGED_IN)
        //        NotificationCenterX.addObserver(target: self, selector: #selector(refreshTableView), name: NOTIFICATION_REFRESH_CHATS)
        //        NotificationCenterX.addObserver(target: self, selector: #selector(refreshTabCounter), name: NOTIFICATION_REFRESH_CHATS)
        //        NotificationCenterX.addObserver(target: self, selector: #selector(refreshTableView), name: NOTIFICATION_REFRESH_STATUSES)
        //        NotificationCenterX.addObserver(target: self, selector: #selector(refreshTabCounter), name: NOTIFICATION_REFRESH_STATUSES)
    }
    
    required init?(coder aDecoder: NSCoder) {
        
        super.init(coder: aDecoder)
    }
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
