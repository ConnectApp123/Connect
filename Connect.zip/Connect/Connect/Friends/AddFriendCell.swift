//
//  AddFriendCell.swift
//  Connect
//
//  Created by zetao on 13/3/2019.
//  Copyright © 2019 zetao. All rights reserved.
//

import UIKit

class AddFriendCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
