//
//  ProfileViewController.swift
//  Connect
//
//  Created by zetao on 13/3/2019.
//  Copyright © 2019 zetao. All rights reserved.
//

import UIKit

class ProfileViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    //点击头像进入大图，可选择相册以及摄像头，设置头像自动缩小图片。
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
